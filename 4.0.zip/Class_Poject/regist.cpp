#include "regist.h"
#include "ui_regist.h"

regist::regist(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::regist)
{
    ui->setupUi(this);
    setWindowTitle("兰州牛肉拉面");//设置窗口标题
}

regist::~regist()
{
    delete ui;
}

//确认注册
void regist::on_pushButton_clicked()
{
    //执行sql语句
    QSqlQuery query;
    QString cmd  = QString("insert into user(id, name) values(%1, '%2')")
            .arg(ui->lineEdit->text()).arg(ui->lineEdit_2->text());

    bool ret = query.exec(cmd);//插入数据进入数据库

    QString id_name = QString("id:%1 name:%2").arg(ui->lineEdit->text()).arg(ui->lineEdit_2->text());
    if(ret){
        QMessageBox::information(this, "五邑大学食堂提醒您","添加成功");
        QMessageBox::information(this, "五邑大学食堂提醒您",id_name);
    }else
    {
         QMessageBox::information(this, "五邑大学食堂提醒您","添加失败");
    }
}

//查询数据库
void regist::on_pushButton_2_clicked()
{
    ui->tableView->setModel(&model);
    model.setTable("user");
    model.select();

}

//返回登录界面
void regist::on_pushButton_3_clicked()
{
    my_login *m = new my_login();
    m->show();
    this->close();//关闭当前界面
}
