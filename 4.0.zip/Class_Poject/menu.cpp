#include "menu.h"
#include "ui_menu.h"
#include "mainwindow.h"
#include <QRandomGenerator>
extern QString my_account;
extern QString my_code;
extern int flag;
extern QString s1;
extern QString s2;
extern QString s3;

menu::menu(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::menu)
{
    ui->setupUi(this);
    QPalette pa(this->palette());
    QImage img = QImage(":/new/prefix1/backg1.jpeg");
    img = img.scaled(this->size());

    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setPalette(pa);

}

menu::~menu()
{
    delete ui;
}

//支付,进入支付界面
void menu::on_pushButton_7_clicked()
{

    MainWindow *p = new MainWindow;
    p->show();
    p->send_sum(sum);
    if(flag==1) p->send_msg(s1,my_account);
    else if(flag==2) p->send_msg(s2,my_account);
    else if(flag==0) p->send_msg(s3,my_account);
    qDebug()<<"sum="<<sum<<endl;
    this->close();
}

//菜品1
void menu::on_pushButton_clicked()
{
    num1++;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}

//菜品2
void menu::on_pushButton_2_clicked()
{
    num2++;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    ui->lcdNumber->display(sum);
    qDebug()<<"2"<<endl;
}

//菜品3
void menu::on_pushButton_3_clicked()
{
    num3++;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    ui->lcdNumber->display(sum);
    qDebug()<<"3"<<endl;
}

//菜品4
void menu::on_pushButton_4_clicked()
{
    num4++;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    ui->lcdNumber->display(sum);
    qDebug()<<"4"<<endl;
}

//菜品6
void menu::on_pushButton_6_clicked()
{
    num6++;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    ui->lcdNumber->display(sum);
    qDebug()<<"6"<<endl;
}

//菜品5
void menu::on_pushButton_5_clicked()
{
    num5++;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    ui->lcdNumber->display(sum);
    qDebug()<<"5"<<endl;
}

void menu::send_Msg(QString msg)
{
    msg = QString("服务工号:%1").arg(msg);
    ui->label_id->setText(msg);

}

void menu::on_pushButton_8_clicked()
{
    num1--;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    if(num1<0) num1=0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}

void menu::on_pushButton_9_clicked()
{
    num2--;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    if(num2<0) num2=0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}

void menu::on_pushButton_10_clicked()
{
    num3--;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    if(num3<0) num3=0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}

void menu::on_pushButton_11_clicked()
{
    num4--;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    if(num4<0) num4=0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}

void menu::on_pushButton_12_clicked()
{
    num5--;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    if(num5<0) num5=0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}

void menu::on_pushButton_13_clicked()
{
    num6--;
    sum = num1 * 19 + num2 * 79 + num3 * 99 + num4 * 39 + num5 * 49 + num6 * 29;
    if(sum<0) sum =0;
    if(num6<0) num6=0;
    ui->lcdNumber->display(sum);
    qDebug()<<"1"<<endl;
}
