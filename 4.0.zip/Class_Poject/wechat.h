#ifndef WECHAT_H
#define WECHAT_H

#include <QMainWindow>

namespace Ui {
class wechat;
}

class wechat : public QMainWindow
{
    Q_OBJECT

public:
    explicit wechat(QWidget *parent = nullptr);
    ~wechat();

private:
    Ui::wechat *ui;
};

#endif // WECHAT_H
