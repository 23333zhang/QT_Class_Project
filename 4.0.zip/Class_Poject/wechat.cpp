#include "wechat.h"
#include "ui_wechat.h"

wechat::wechat(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::wechat)
{
    ui->setupUi(this);
    resize(745,1014);
    QPalette pa(this->palette());
    QImage img = QImage(":/new/prefix1/my.jpg");
    img = img.scaled(this->size());

    QBrush *pic = new QBrush(img);

    pa.setBrush(QPalette::Window,*pic);

    this->setPalette(pa);
}

wechat::~wechat()
{
    delete ui;
}
