#include "my_login.h"
#include "ui_my_login.h"
#include "mainwindow.h"
#include <QDebug>
#include <QMessageBox>
#include "regist.h"
#include <QSqlQuery>
#include <QSqlRecord>
#include "menu.h"
QString my_account;
QString my_code;
int flag  = 0;
QString s1 = "border-image: url(:/new/prefix1/1.jpeg);";
QString s2 = "border-image: url(:/new/prefix1/2.jpeg);";
QString s3 = "border-image: url(:/new/prefix1/3.jpeg);";
my_login::my_login(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::my_login)
{
    ui->setupUi(this);//登录界面
    setWindowTitle("兰州牛肉拉面");//设置窗口标题
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);

    this->resize(800,480);
    QPalette pa(this->palette());
    QImage img = QImage(":/new/prefix1/background.jpg");
    img = img.scaled(this->size());

    QBrush *pic = new QBrush(img);

    pa.setBrush(QPalette::Window,*pic);

    this->setPalette(pa);
}

my_login::~my_login()
{
    delete ui;
}

//登录
void my_login::on_pushButton_clicked()
{
    my_account = ui->lineEdit->text();
    my_code = ui->lineEdit_2->text();
    QString sql=QString("select * from user where id='%1' and name='%2'")
            .arg(my_account).arg(my_code);//数据库查询
    QSqlQuery query(sql);

    //判断执行结果
    if(query.next()||(my_account == "wyu" && my_code == "123"))
    {
        qDebug()<<"Login success";
        QMessageBox::information(this,"五邑大学食堂提醒您","登录成功");
        //登录成功后可以跳转到其他页面
        menu *m = new menu;
        m->show();
        m->send_Msg(my_account);
//        MainWindow *p = new MainWindow;
//        if(flag==1) p->send_msg(s1,my_account);
//        else if(flag==2) p->send_msg(s2,my_account);
//        else if(flag==0) p->send_msg(s3,my_account);
//        p->show();
        this->close();
    }
    else
    {
         qDebug()<<"Login error";
         QMessageBox::critical(this,"深夜食堂提醒您","您的电脑账号密码输入错误！");
    }
}


//更换头像
void my_login::on_pushButton_3_clicked()
{
    flag++;

    if(flag==1)
    {
        ui->label->setStyleSheet(s1);
    }
    else if(flag==2)
    {
        ui->label->setStyleSheet(s2);
    }
    else if(flag==3) {
        ui->label->setStyleSheet(s3);
        flag=0;
    }

}

//进入注册界面
void my_login::on_pushButton_2_clicked()
{
    regist *p = new regist();
    p->show();
    this->close();//关闭当前界面
}
