#include "mainwindow.h"
#include "my_login.h"
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    //创建数据库对象
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE"); //连接sqlite3

    //设置数据库名称
    db.setDatabaseName("my.db");

    //打开数据库
    bool ret = db.open();
    if(!ret)
    {
        qDebug()<< db.lastError().text();//错误提示
        return -1;
    }

    QSqlQuery query; //创建对象的时候会自动关联到默认连接的数据

    //create table:创建表格 user；表格名 user(类型 内容)
    ret = query.exec("create table if not exists user(id integer primay key, name varchar(255))");//SQL语句
    if(!ret)
    {
        qDebug()<<query.lastError().text();
    }

    my_login m;//创建登陆界面对象
    m.show();//登陆界面

    return a.exec();
}
