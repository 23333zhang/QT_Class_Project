#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlDatabase>
#include "wechat.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("深夜食堂");//设置窗口标题
    connect(&mtimer,&QTimer::timeout,this,&MainWindow::update_video);
    qDebug() << "进入主界面" << endl;

}

MainWindow::~MainWindow()
{
    delete ui;
}

//传输数据
void MainWindow::send_msg(QString pic,QString acc)
{
    my_acc = acc;
    my_pic = pic;
    acc =  QString("尊敬的VIP用户%1").arg(acc);
    qDebug()<<acc<<endl;
    qDebug()<<pic<<endl;
    ui->label->setStyleSheet(pic);//传递头像
    ui->label_2->setText(acc);//传递账户名

}

//定时器
void MainWindow::update_video()
{
    qDebug() << "定时器" << endl;

    CascadeClassifier cascade;//级联分类器
    cascade.load("C:/opencv452/opencv452/etc/haarcascades/haarcascade_frontalface_default.xml");
    //导入分类器文件

    //采集一帧数据
    cap >> srcImage;

    //把opencv里面的Mat转化QT中QImage
    cv::cvtColor(srcImage,gratImage,cv::COLOR_RGBA2RGB);

    //监测人脸
    std::vector<cv::Rect> faceRects;//创建一个矩形

    cascade.detectMultiScale(srcImage,faceRects,1.1,3,0,cv::Size(100,100));
    count = faceRects.size();
    ui->lcdNumber_2->display(count);
    if(faceRects.size()>0)//大于零就代表有人脸
    {
       qDebug()  << "监测到人脸" << endl;
        cv::rectangle(srcImage,faceRects[1],cv::Scalar(0,255,0),1,LINE_AA);
        //第0个矩形,画图的颜色，线的大小
    }

    QImage image(srcImage.data,srcImage.cols,srcImage.rows,srcImage.step1(),QImage::Format_RGB888);
    QPixmap mmp = QPixmap::fromImage(image);

    ui->label_3->setPixmap(mmp);

}

//人脸识别按钮
void MainWindow::on_pushButton_5_clicked()
{
    qDebug() << "开启" << endl;
    if(mtimer.isActive())
    {
        mtimer.stop();
        cap.release();//关闭摄像头
    }
    else {
        cap.open(0);//打开摄像头
        mtimer.start(1);//ms级刷新
    }
}

//图片文件选择
void MainWindow::on_pushButton_6_clicked()
{
    if(!pictrue)
    {
        pictruename = QFileDialog::getOpenFileName(this); //手动打开图片，用于识别
    }
    pictrue = !pictrue;
}

//在支付界面显示金额
void MainWindow::send_sum(int sum)
{
    my_sum = sum;
    ui->lcdNumber->display(sum);
}

//跳转微信支付
void MainWindow::on_pushButton_7_clicked()
{
    wechat *w = new wechat();
    w->show();
}

//服务叫号
void MainWindow::on_pushButton_9_clicked()
{
    QMessageBox::information(this, "五邑大学食堂提醒您","服务叫号成功，请稍后...");
}

//打印小票
void MainWindow::on_pushButton_8_clicked()
{
    QMessageBox::information(this, "五邑大学食堂提醒您","打印小票中...");
}

//现金支付
void MainWindow::on_pushButton_3_clicked()
{
     QMessageBox::information(this, "五邑大学食堂提醒您","请前往前台支付。");
}

//拍照
void MainWindow::on_pushButton_10_clicked()
{
    QImage image(srcImage.data,srcImage.cols,srcImage.rows,srcImage.step1(),QImage::Format_RGB888);
    QPixmap mmp = QPixmap::fromImage(image);
    mmp = mmp.scaled(ui->label_7->size());//自适应调整大小
    ui->label_7->setPixmap(mmp);//显示照片
}

//关闭摄像头
void MainWindow::on_pushButton_11_clicked()
{
    mtimer.stop();//定时器关闭
    cap.release();//关闭摄像头
    ui->label_3->setPixmap(pic);//将画面清空
}
