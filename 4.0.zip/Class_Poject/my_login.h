#ifndef MY_LOGIN_H
#define MY_LOGIN_H

#include <QMainWindow>

namespace Ui {
class my_login;
}

class my_login : public QMainWindow
{
    Q_OBJECT

public:
    explicit my_login(QWidget *parent = nullptr);
    ~my_login();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::my_login *ui;


};

#endif // MY_LOGIN_H
