#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <opencv.hpp>
#include <opencv.hpp>
#include <vector>
#include <QDebug>
#include <QFileDialog>
using namespace cv;
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void send_msg(QString pic,QString acc);
    void update_video();
    void send_sum(int sum);

private slots:
    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_11_clicked();

private:
    Ui::MainWindow *ui;
    QString my_pic;//头像
    QString my_acc;//账户名
    QTimer mtimer;//创建定时器对象
    cv::VideoCapture cap;//创建一个opencv摄像头对象
    cv::VideoCapture cap2;
    cv::Mat srcImage;
    cv::Mat gratImage;
    QPixmap pic;
    int count;//人脸个数
    //图片
    bool pictrue;
    QString pictruename;

    int my_sum = 0;

};
#endif // MAINWINDOW_H
